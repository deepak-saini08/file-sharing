
def send_email(to_email: str, link: str):
    print(f" Simulated email to {to_email}: {link}")
