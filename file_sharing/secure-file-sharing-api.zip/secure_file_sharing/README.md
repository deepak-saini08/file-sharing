# secure-file-sharing-api
Two-way Secure File Sharing Application on the Local Network

Example Usage:

```bash


```

It will open a server on `https://<your_ip>:8080`. Go this website on client's browser.

Files can be shared by both server and client on this website